// Generated from Cactus.g4 by ANTLR 4.7
import org.antlr.v4.runtime.atn.*;
import org.antlr.v4.runtime.dfa.DFA;
import org.antlr.v4.runtime.*;
import org.antlr.v4.runtime.misc.*;
import org.antlr.v4.runtime.tree.*;
import java.util.List;
import java.util.Iterator;
import java.util.ArrayList;

@SuppressWarnings({"all", "warnings", "unchecked", "unused", "cast"})
public class CactusParser extends Parser {
	static { RuntimeMetaData.checkVersion("4.7", RuntimeMetaData.VERSION); }

	protected static final DFA[] _decisionToDFA;
	protected static final PredictionContextCache _sharedContextCache =
		new PredictionContextCache();
	public static final int
		ELSE=1, FI=2, IF=3, INT=4, MAIN=5, RETURN=6, WHILE=7, READ=8, WRITE=9, 
		CONST=10, SEMICOLON=11, ID=12, WHITESPACE=13, COMMENT=14, ADD=15, MINUS=16, 
		MULTIPLY=17, DIVIDE=18, PERCENTAGE=19, ISEQUAL=20, NOTEQUAL=21, GREATER=22, 
		GREATEREQUAL=23, LESS=24, LESSEQUAL=25, LOGICALAND=26, LOGICALOR=27, NOT=28, 
		ASSIGNMENT=29, LEFTBRACE=30, RIGHTBRACE=31, LEFTPARENTHESIS=32, RIGHTPARENTHESIS=33;
	public static final int
		RULE_program = 0, RULE_declarations = 1, RULE_statements = 2, RULE_statement = 3, 
		RULE_else_statement = 4, RULE_bool_expression = 5, RULE_bool_expression1 = 6, 
		RULE_bool_term = 7, RULE_bool_term1 = 8, RULE_bool_factor = 9, RULE_rel_expression = 10, 
		RULE_relation_op = 11, RULE_arith_expression = 12, RULE_arith_expression1 = 13, 
		RULE_arith_term = 14, RULE_arith_term1 = 15, RULE_arith_factor = 16, RULE_primary_expression = 17, 
		RULE_token = 18;
	public static final String[] ruleNames = {
		"program", "declarations", "statements", "statement", "else_statement", 
		"bool_expression", "bool_expression1", "bool_term", "bool_term1", "bool_factor", 
		"rel_expression", "relation_op", "arith_expression", "arith_expression1", 
		"arith_term", "arith_term1", "arith_factor", "primary_expression", "token"
	};

	private static final String[] _LITERAL_NAMES = {
		null, "'else'", "'fi'", "'if'", "'int'", "'main'", "'return'", "'while'", 
		"'read'", "'write'", null, "';'", null, null, null, "'+'", "'-'", "'*'", 
		"'/'", "'%'", "'=='", "'!='", "'>'", "'>='", "'<'", "'<='", "'&&'", "'||'", 
		"'!'", "'='", "'{'", "'}'", "'('", "')'"
	};
	private static final String[] _SYMBOLIC_NAMES = {
		null, "ELSE", "FI", "IF", "INT", "MAIN", "RETURN", "WHILE", "READ", "WRITE", 
		"CONST", "SEMICOLON", "ID", "WHITESPACE", "COMMENT", "ADD", "MINUS", "MULTIPLY", 
		"DIVIDE", "PERCENTAGE", "ISEQUAL", "NOTEQUAL", "GREATER", "GREATEREQUAL", 
		"LESS", "LESSEQUAL", "LOGICALAND", "LOGICALOR", "NOT", "ASSIGNMENT", "LEFTBRACE", 
		"RIGHTBRACE", "LEFTPARENTHESIS", "RIGHTPARENTHESIS"
	};
	public static final Vocabulary VOCABULARY = new VocabularyImpl(_LITERAL_NAMES, _SYMBOLIC_NAMES);

	/**
	 * @deprecated Use {@link #VOCABULARY} instead.
	 */
	@Deprecated
	public static final String[] tokenNames;
	static {
		tokenNames = new String[_SYMBOLIC_NAMES.length];
		for (int i = 0; i < tokenNames.length; i++) {
			tokenNames[i] = VOCABULARY.getLiteralName(i);
			if (tokenNames[i] == null) {
				tokenNames[i] = VOCABULARY.getSymbolicName(i);
			}

			if (tokenNames[i] == null) {
				tokenNames[i] = "<INVALID>";
			}
		}
	}

	@Override
	@Deprecated
	public String[] getTokenNames() {
		return tokenNames;
	}

	@Override

	public Vocabulary getVocabulary() {
		return VOCABULARY;
	}

	@Override
	public String getGrammarFileName() { return "Cactus.g4"; }

	@Override
	public String[] getRuleNames() { return ruleNames; }

	@Override
	public String getSerializedATN() { return _serializedATN; }

	@Override
	public ATN getATN() { return _ATN; }

	public CactusParser(TokenStream input) {
		super(input);
		_interp = new ParserATNSimulator(this,_ATN,_decisionToDFA,_sharedContextCache);
	}
	public static class ProgramContext extends ParserRuleContext {
		public TerminalNode MAIN() { return getToken(CactusParser.MAIN, 0); }
		public TerminalNode LEFTPARENTHESIS() { return getToken(CactusParser.LEFTPARENTHESIS, 0); }
		public TerminalNode RIGHTPARENTHESIS() { return getToken(CactusParser.RIGHTPARENTHESIS, 0); }
		public TerminalNode LEFTBRACE() { return getToken(CactusParser.LEFTBRACE, 0); }
		public DeclarationsContext declarations() {
			return getRuleContext(DeclarationsContext.class,0);
		}
		public StatementsContext statements() {
			return getRuleContext(StatementsContext.class,0);
		}
		public TerminalNode RIGHTBRACE() { return getToken(CactusParser.RIGHTBRACE, 0); }
		public ProgramContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_program; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof CactusListener ) ((CactusListener)listener).enterProgram(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof CactusListener ) ((CactusListener)listener).exitProgram(this);
		}
	}

	public final ProgramContext program() throws RecognitionException {
		ProgramContext _localctx = new ProgramContext(_ctx, getState());
		enterRule(_localctx, 0, RULE_program);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(38);
			match(MAIN);
			setState(39);
			match(LEFTPARENTHESIS);
			setState(40);
			match(RIGHTPARENTHESIS);
			setState(41);
			match(LEFTBRACE);

						System.out.println("\t.data");
					
			setState(43);
			declarations();

						System.out.println("\t.text");
						System.out.println("main:");
					
			setState(45);
			statements(0, 1);
			setState(46);
			match(RIGHTBRACE);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class DeclarationsContext extends ParserRuleContext {
		public Token ID;
		public TerminalNode INT() { return getToken(CactusParser.INT, 0); }
		public TerminalNode ID() { return getToken(CactusParser.ID, 0); }
		public TerminalNode SEMICOLON() { return getToken(CactusParser.SEMICOLON, 0); }
		public DeclarationsContext declarations() {
			return getRuleContext(DeclarationsContext.class,0);
		}
		public DeclarationsContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_declarations; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof CactusListener ) ((CactusListener)listener).enterDeclarations(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof CactusListener ) ((CactusListener)listener).exitDeclarations(this);
		}
	}

	public final DeclarationsContext declarations() throws RecognitionException {
		DeclarationsContext _localctx = new DeclarationsContext(_ctx, getState());
		enterRule(_localctx, 2, RULE_declarations);
		try {
			setState(54);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case INT:
				enterOuterAlt(_localctx, 1);
				{
				setState(48);
				match(INT);
				setState(49);
				((DeclarationsContext)_localctx).ID = match(ID);
				setState(50);
				match(SEMICOLON);
				System.out.println((((DeclarationsContext)_localctx).ID!=null?((DeclarationsContext)_localctx).ID.getText():null) + ":\t.word 0");
				setState(52);
				declarations();
				}
				break;
			case IF:
			case RETURN:
			case WHILE:
			case READ:
			case WRITE:
			case ID:
			case RIGHTBRACE:
				enterOuterAlt(_localctx, 2);
				{
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class StatementsContext extends ParserRuleContext {
		public int reg;
		public int label;
		public int nreg;
		public int nlabel;
		public StatementContext ret;
		public StatementsContext ret1;
		public StatementContext statement() {
			return getRuleContext(StatementContext.class,0);
		}
		public StatementsContext statements() {
			return getRuleContext(StatementsContext.class,0);
		}
		public StatementsContext(ParserRuleContext parent, int invokingState) { super(parent, invokingState); }
		public StatementsContext(ParserRuleContext parent, int invokingState, int reg, int label) {
			super(parent, invokingState);
			this.reg = reg;
			this.label = label;
		}
		@Override public int getRuleIndex() { return RULE_statements; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof CactusListener ) ((CactusListener)listener).enterStatements(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof CactusListener ) ((CactusListener)listener).exitStatements(this);
		}
	}

	public final StatementsContext statements(int reg,int label) throws RecognitionException {
		StatementsContext _localctx = new StatementsContext(_ctx, getState(), reg, label);
		enterRule(_localctx, 4, RULE_statements);
		try {
			setState(61);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case IF:
			case RETURN:
			case WHILE:
			case READ:
			case WRITE:
			case ID:
				enterOuterAlt(_localctx, 1);
				{
				setState(56);
				((StatementsContext)_localctx).ret = statement(_localctx.reg, _localctx.label);
				setState(57);
				((StatementsContext)_localctx).ret1 = statements(((StatementsContext)_localctx).ret.nreg, ((StatementsContext)_localctx).ret.nlabel);

					((StatementsContext)_localctx).nreg =  ((StatementsContext)_localctx).ret1.nreg;
					((StatementsContext)_localctx).nlabel =  ((StatementsContext)_localctx).ret1.nlabel;

				}
				break;
			case RIGHTBRACE:
				enterOuterAlt(_localctx, 2);
				{

					((StatementsContext)_localctx).nreg =  _localctx.reg;
					((StatementsContext)_localctx).nlabel =  _localctx.label;

				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class StatementContext extends ParserRuleContext {
		public int reg;
		public int label;
		public int nreg;
		public int nlabel;
		public Token ID;
		public Arith_expressionContext ret;
		public Bool_expressionContext ret11;
		public StatementsContext ret5;
		public StatementsContext ret1;
		public Else_statementContext ret2;
		public TerminalNode ID() { return getToken(CactusParser.ID, 0); }
		public TerminalNode ASSIGNMENT() { return getToken(CactusParser.ASSIGNMENT, 0); }
		public TerminalNode SEMICOLON() { return getToken(CactusParser.SEMICOLON, 0); }
		public Arith_expressionContext arith_expression() {
			return getRuleContext(Arith_expressionContext.class,0);
		}
		public TerminalNode READ() { return getToken(CactusParser.READ, 0); }
		public TerminalNode WRITE() { return getToken(CactusParser.WRITE, 0); }
		public TerminalNode RETURN() { return getToken(CactusParser.RETURN, 0); }
		public TerminalNode WHILE() { return getToken(CactusParser.WHILE, 0); }
		public TerminalNode LEFTPARENTHESIS() { return getToken(CactusParser.LEFTPARENTHESIS, 0); }
		public TerminalNode RIGHTPARENTHESIS() { return getToken(CactusParser.RIGHTPARENTHESIS, 0); }
		public TerminalNode LEFTBRACE() { return getToken(CactusParser.LEFTBRACE, 0); }
		public TerminalNode RIGHTBRACE() { return getToken(CactusParser.RIGHTBRACE, 0); }
		public Bool_expressionContext bool_expression() {
			return getRuleContext(Bool_expressionContext.class,0);
		}
		public StatementsContext statements() {
			return getRuleContext(StatementsContext.class,0);
		}
		public TerminalNode IF() { return getToken(CactusParser.IF, 0); }
		public TerminalNode FI() { return getToken(CactusParser.FI, 0); }
		public Else_statementContext else_statement() {
			return getRuleContext(Else_statementContext.class,0);
		}
		public StatementContext(ParserRuleContext parent, int invokingState) { super(parent, invokingState); }
		public StatementContext(ParserRuleContext parent, int invokingState, int reg, int label) {
			super(parent, invokingState);
			this.reg = reg;
			this.label = label;
		}
		@Override public int getRuleIndex() { return RULE_statement; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof CactusListener ) ((CactusListener)listener).enterStatement(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof CactusListener ) ((CactusListener)listener).exitStatement(this);
		}
	}

	public final StatementContext statement(int reg,int label) throws RecognitionException {
		StatementContext _localctx = new StatementContext(_ctx, getState(), reg, label);
		enterRule(_localctx, 6, RULE_statement);
		try {
			setState(105);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case ID:
				enterOuterAlt(_localctx, 1);
				{
				setState(63);
				((StatementContext)_localctx).ID = match(ID);
				setState(64);
				match(ASSIGNMENT);
				setState(65);
				((StatementContext)_localctx).ret = arith_expression(_localctx.reg);

					System.out.println("\tla $t" + ((StatementContext)_localctx).ret.nreg + ", " + (((StatementContext)_localctx).ID!=null?((StatementContext)_localctx).ID.getText():null));
					System.out.println("\tsw $t" + ((StatementContext)_localctx).ret.place + ", 0($t" + ((StatementContext)_localctx).ret.nreg + ")");

					((StatementContext)_localctx).nreg =  ((StatementContext)_localctx).ret.nreg - 1;
					((StatementContext)_localctx).nlabel =  _localctx.label;

				setState(67);
				match(SEMICOLON);
				}
				break;
			case READ:
				enterOuterAlt(_localctx, 2);
				{
				setState(69);
				match(READ);
				setState(70);
				match(ID);

					System.out.println("\tli $v0, 5");
					System.out.println("\tsyscall");
					System.out.println("\tla $t" + _localctx.reg + ", n");
					System.out.println("\tsw $v0, 0($t" + _localctx.reg + ")");

					((StatementContext)_localctx).nreg =  _localctx.reg;
					((StatementContext)_localctx).nlabel =  _localctx.label;

				setState(72);
				match(SEMICOLON);
				}
				break;
			case WRITE:
				enterOuterAlt(_localctx, 3);
				{
				setState(73);
				match(WRITE);
				setState(74);
				((StatementContext)_localctx).ret = arith_expression(_localctx.reg);

					System.out.println("\tmove $a0, $t" + ((StatementContext)_localctx).ret.place);
					System.out.println("\tli $v0, 1");
					System.out.println("\tsyscall");

					((StatementContext)_localctx).nreg =  _localctx.reg;
					((StatementContext)_localctx).nlabel =  _localctx.label;

				setState(76);
				match(SEMICOLON);
				}
				break;
			case RETURN:
				enterOuterAlt(_localctx, 4);
				{
				setState(78);
				match(RETURN);

					System.out.println("\tli $v0, 10");
					System.out.println("\tsyscall");

					((StatementContext)_localctx).nreg =  _localctx.reg;
					((StatementContext)_localctx).nlabel =  _localctx.label;

				setState(80);
				match(SEMICOLON);
				}
				break;
			case WHILE:
				enterOuterAlt(_localctx, 5);
				{

					System.out.println("L" + (_localctx.label) + ":");

				setState(82);
				match(WHILE);
				setState(83);
				match(LEFTPARENTHESIS);
				setState(84);
				((StatementContext)_localctx).ret11 = bool_expression(_localctx.reg, _localctx.label + 3, _localctx.label + 1, _localctx.label + 2);
				setState(85);
				match(RIGHTPARENTHESIS);
				setState(86);
				match(LEFTBRACE);

					System.out.println("L" + (_localctx.label + 1) + ":");

				setState(88);
				((StatementContext)_localctx).ret5 = statements(_localctx.reg, ((StatementContext)_localctx).ret11.nlabel);
				setState(89);
				match(RIGHTBRACE);

					System.out.println("\tb L" + _localctx.label);
					System.out.println("L" + (_localctx.label + 2) + ":");

					((StatementContext)_localctx).nreg =  ((StatementContext)_localctx).ret5.nreg;
					((StatementContext)_localctx).nlabel =  ((StatementContext)_localctx).ret5.nlabel;

				}
				break;
			case IF:
				enterOuterAlt(_localctx, 6);
				{
				setState(92);
				match(IF);
				setState(93);
				match(LEFTPARENTHESIS);
				setState(94);
				((StatementContext)_localctx).ret11 = bool_expression(_localctx.reg, _localctx.label + 3, _localctx.label, _localctx.label + 1);
				setState(95);
				match(RIGHTPARENTHESIS);
				setState(96);
				match(LEFTBRACE);

					System.out.println("L" + (_localctx.label) + ":");

				setState(98);
				((StatementContext)_localctx).ret1 = statements(_localctx.reg, ((StatementContext)_localctx).ret11.nlabel);
				setState(99);
				match(RIGHTBRACE);

					System.out.println("\tb L" + (_localctx.label + 2));
					System.out.println("L" + (_localctx.label + 1) + ":");

				setState(101);
				((StatementContext)_localctx).ret2 = else_statement(((StatementContext)_localctx).ret1.nreg, ((StatementContext)_localctx).ret1.nlabel);
				setState(102);
				match(FI);

					System.out.println("L" + (_localctx.label + 2)+ ":");
					((StatementContext)_localctx).nreg =  ((StatementContext)_localctx).ret2.nreg;
					((StatementContext)_localctx).nlabel =  ((StatementContext)_localctx).ret2.nlabel;

				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Else_statementContext extends ParserRuleContext {
		public int reg;
		public int label;
		public int nreg;
		public int nlabel;
		public StatementsContext ret;
		public TerminalNode ELSE() { return getToken(CactusParser.ELSE, 0); }
		public TerminalNode LEFTBRACE() { return getToken(CactusParser.LEFTBRACE, 0); }
		public TerminalNode RIGHTBRACE() { return getToken(CactusParser.RIGHTBRACE, 0); }
		public StatementsContext statements() {
			return getRuleContext(StatementsContext.class,0);
		}
		public Else_statementContext(ParserRuleContext parent, int invokingState) { super(parent, invokingState); }
		public Else_statementContext(ParserRuleContext parent, int invokingState, int reg, int label) {
			super(parent, invokingState);
			this.reg = reg;
			this.label = label;
		}
		@Override public int getRuleIndex() { return RULE_else_statement; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof CactusListener ) ((CactusListener)listener).enterElse_statement(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof CactusListener ) ((CactusListener)listener).exitElse_statement(this);
		}
	}

	public final Else_statementContext else_statement(int reg,int label) throws RecognitionException {
		Else_statementContext _localctx = new Else_statementContext(_ctx, getState(), reg, label);
		enterRule(_localctx, 8, RULE_else_statement);
		try {
			setState(114);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case ELSE:
				enterOuterAlt(_localctx, 1);
				{
				setState(107);
				match(ELSE);
				setState(108);
				match(LEFTBRACE);
				setState(109);
				((Else_statementContext)_localctx).ret = statements(_localctx.reg, _localctx.label);
				setState(110);
				match(RIGHTBRACE);

					((Else_statementContext)_localctx).nreg =  ((Else_statementContext)_localctx).ret.nreg;
					((Else_statementContext)_localctx).nlabel =  ((Else_statementContext)_localctx).ret.nlabel;

				}
				break;
			case FI:
				enterOuterAlt(_localctx, 2);
				{

					((Else_statementContext)_localctx).nreg =  _localctx.reg;
					((Else_statementContext)_localctx).nlabel =  _localctx.label;

				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Bool_expressionContext extends ParserRuleContext {
		public int reg;
		public int label;
		public int btrue;
		public int bfalse;
		public int nlabel;
		public Bool_termContext ret;
		public Bool_expression1Context ret1;
		public Bool_termContext bool_term() {
			return getRuleContext(Bool_termContext.class,0);
		}
		public Bool_expression1Context bool_expression1() {
			return getRuleContext(Bool_expression1Context.class,0);
		}
		public Bool_expressionContext(ParserRuleContext parent, int invokingState) { super(parent, invokingState); }
		public Bool_expressionContext(ParserRuleContext parent, int invokingState, int reg, int label, int btrue, int bfalse) {
			super(parent, invokingState);
			this.reg = reg;
			this.label = label;
			this.btrue = btrue;
			this.bfalse = bfalse;
		}
		@Override public int getRuleIndex() { return RULE_bool_expression; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof CactusListener ) ((CactusListener)listener).enterBool_expression(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof CactusListener ) ((CactusListener)listener).exitBool_expression(this);
		}
	}

	public final Bool_expressionContext bool_expression(int reg,int label,int btrue,int bfalse) throws RecognitionException {
		Bool_expressionContext _localctx = new Bool_expressionContext(_ctx, getState(), reg, label, btrue, bfalse);
		enterRule(_localctx, 10, RULE_bool_expression);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(116);
			((Bool_expressionContext)_localctx).ret = bool_term(_localctx.reg, _localctx.label, _localctx.btrue, _localctx.bfalse);
			setState(117);
			((Bool_expressionContext)_localctx).ret1 = bool_expression1(_localctx.reg, ((Bool_expressionContext)_localctx).ret.nlabel, _localctx.btrue, _localctx.bfalse);

				((Bool_expressionContext)_localctx).nlabel =  ((Bool_expressionContext)_localctx).ret1.nlabel;

			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Bool_expression1Context extends ParserRuleContext {
		public int reg;
		public int label;
		public int btrue;
		public int bfalse;
		public int nlabel;
		public Bool_termContext ret;
		public Bool_expression1Context ret1;
		public TerminalNode LOGICALOR() { return getToken(CactusParser.LOGICALOR, 0); }
		public Bool_termContext bool_term() {
			return getRuleContext(Bool_termContext.class,0);
		}
		public Bool_expression1Context bool_expression1() {
			return getRuleContext(Bool_expression1Context.class,0);
		}
		public Bool_expression1Context(ParserRuleContext parent, int invokingState) { super(parent, invokingState); }
		public Bool_expression1Context(ParserRuleContext parent, int invokingState, int reg, int label, int btrue, int bfalse) {
			super(parent, invokingState);
			this.reg = reg;
			this.label = label;
			this.btrue = btrue;
			this.bfalse = bfalse;
		}
		@Override public int getRuleIndex() { return RULE_bool_expression1; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof CactusListener ) ((CactusListener)listener).enterBool_expression1(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof CactusListener ) ((CactusListener)listener).exitBool_expression1(this);
		}
	}

	public final Bool_expression1Context bool_expression1(int reg,int label,int btrue,int bfalse) throws RecognitionException {
		Bool_expression1Context _localctx = new Bool_expression1Context(_ctx, getState(), reg, label, btrue, bfalse);
		enterRule(_localctx, 12, RULE_bool_expression1);
		try {
			setState(126);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case LOGICALOR:
				enterOuterAlt(_localctx, 1);
				{
				setState(120);
				match(LOGICALOR);
				setState(121);
				((Bool_expression1Context)_localctx).ret = bool_term(_localctx.reg, _localctx.label, _localctx.btrue, _localctx.bfalse);
				setState(122);
				((Bool_expression1Context)_localctx).ret1 = bool_expression1(_localctx.reg, ((Bool_expression1Context)_localctx).ret.nlabel, _localctx.btrue, _localctx.bfalse);

					((Bool_expression1Context)_localctx).nlabel =  ((Bool_expression1Context)_localctx).ret1.nlabel;

				}
				break;
			case RIGHTPARENTHESIS:
				enterOuterAlt(_localctx, 2);
				{

					System.out.println("\tb L" + _localctx.bfalse);
					((Bool_expression1Context)_localctx).nlabel =  _localctx.label;

				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Bool_termContext extends ParserRuleContext {
		public int reg;
		public int label;
		public int btrue;
		public int bfalse;
		public int nlabel;
		public Bool_factorContext ret;
		public Bool_term1Context ret1;
		public Bool_factorContext bool_factor() {
			return getRuleContext(Bool_factorContext.class,0);
		}
		public Bool_term1Context bool_term1() {
			return getRuleContext(Bool_term1Context.class,0);
		}
		public Bool_termContext(ParserRuleContext parent, int invokingState) { super(parent, invokingState); }
		public Bool_termContext(ParserRuleContext parent, int invokingState, int reg, int label, int btrue, int bfalse) {
			super(parent, invokingState);
			this.reg = reg;
			this.label = label;
			this.btrue = btrue;
			this.bfalse = bfalse;
		}
		@Override public int getRuleIndex() { return RULE_bool_term; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof CactusListener ) ((CactusListener)listener).enterBool_term(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof CactusListener ) ((CactusListener)listener).exitBool_term(this);
		}
	}

	public final Bool_termContext bool_term(int reg,int label,int btrue,int bfalse) throws RecognitionException {
		Bool_termContext _localctx = new Bool_termContext(_ctx, getState(), reg, label, btrue, bfalse);
		enterRule(_localctx, 14, RULE_bool_term);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(128);
			((Bool_termContext)_localctx).ret = bool_factor(_localctx.reg, _localctx.label, _localctx.btrue, _localctx.bfalse);
			setState(129);
			((Bool_termContext)_localctx).ret1 = bool_term1(_localctx.reg, ((Bool_termContext)_localctx).ret.nlabel, _localctx.btrue, _localctx.bfalse);

				((Bool_termContext)_localctx).nlabel =  ((Bool_termContext)_localctx).ret1.nlabel;

			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Bool_term1Context extends ParserRuleContext {
		public int reg;
		public int label;
		public int btrue;
		public int bfalse;
		public int nlabel;
		public Bool_factorContext ret;
		public Bool_term1Context ret1;
		public TerminalNode LOGICALAND() { return getToken(CactusParser.LOGICALAND, 0); }
		public Bool_factorContext bool_factor() {
			return getRuleContext(Bool_factorContext.class,0);
		}
		public Bool_term1Context bool_term1() {
			return getRuleContext(Bool_term1Context.class,0);
		}
		public Bool_term1Context(ParserRuleContext parent, int invokingState) { super(parent, invokingState); }
		public Bool_term1Context(ParserRuleContext parent, int invokingState, int reg, int label, int btrue, int bfalse) {
			super(parent, invokingState);
			this.reg = reg;
			this.label = label;
			this.btrue = btrue;
			this.bfalse = bfalse;
		}
		@Override public int getRuleIndex() { return RULE_bool_term1; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof CactusListener ) ((CactusListener)listener).enterBool_term1(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof CactusListener ) ((CactusListener)listener).exitBool_term1(this);
		}
	}

	public final Bool_term1Context bool_term1(int reg,int label,int btrue,int bfalse) throws RecognitionException {
		Bool_term1Context _localctx = new Bool_term1Context(_ctx, getState(), reg, label, btrue, bfalse);
		enterRule(_localctx, 16, RULE_bool_term1);
		try {
			setState(138);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case LOGICALAND:
				enterOuterAlt(_localctx, 1);
				{
				setState(132);
				match(LOGICALAND);
				setState(133);
				((Bool_term1Context)_localctx).ret = bool_factor(_localctx.reg, _localctx.label, _localctx.btrue, _localctx.bfalse);
				setState(134);
				((Bool_term1Context)_localctx).ret1 = bool_term1(_localctx.reg, ((Bool_term1Context)_localctx).ret.nlabel, _localctx.btrue, _localctx.bfalse);

					((Bool_term1Context)_localctx).nlabel =  ((Bool_term1Context)_localctx).ret1.nlabel;

				}
				break;
			case LOGICALOR:
			case RIGHTPARENTHESIS:
				enterOuterAlt(_localctx, 2);
				{

					((Bool_term1Context)_localctx).nlabel =  _localctx.label;

				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Bool_factorContext extends ParserRuleContext {
		public int reg;
		public int label;
		public int btrue;
		public int bfalse;
		public int nlabel;
		public Bool_factorContext ret1;
		public Rel_expressionContext ret;
		public TerminalNode NOT() { return getToken(CactusParser.NOT, 0); }
		public Bool_factorContext bool_factor() {
			return getRuleContext(Bool_factorContext.class,0);
		}
		public Rel_expressionContext rel_expression() {
			return getRuleContext(Rel_expressionContext.class,0);
		}
		public Bool_factorContext(ParserRuleContext parent, int invokingState) { super(parent, invokingState); }
		public Bool_factorContext(ParserRuleContext parent, int invokingState, int reg, int label, int btrue, int bfalse) {
			super(parent, invokingState);
			this.reg = reg;
			this.label = label;
			this.btrue = btrue;
			this.bfalse = bfalse;
		}
		@Override public int getRuleIndex() { return RULE_bool_factor; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof CactusListener ) ((CactusListener)listener).enterBool_factor(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof CactusListener ) ((CactusListener)listener).exitBool_factor(this);
		}
	}

	public final Bool_factorContext bool_factor(int reg,int label,int btrue,int bfalse) throws RecognitionException {
		Bool_factorContext _localctx = new Bool_factorContext(_ctx, getState(), reg, label, btrue, bfalse);
		enterRule(_localctx, 18, RULE_bool_factor);
		try {
			setState(147);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case NOT:
				enterOuterAlt(_localctx, 1);
				{
				setState(140);
				match(NOT);
				setState(141);
				((Bool_factorContext)_localctx).ret1 = bool_factor(_localctx.reg, _localctx.label, _localctx.bfalse, _localctx.btrue);

					((Bool_factorContext)_localctx).nlabel =  ((Bool_factorContext)_localctx).ret1.nlabel;

				}
				break;
			case CONST:
			case ID:
			case MINUS:
			case LEFTPARENTHESIS:
				enterOuterAlt(_localctx, 2);
				{
				setState(144);
				((Bool_factorContext)_localctx).ret = rel_expression(_localctx.reg, _localctx.label, _localctx.btrue, _localctx.bfalse);

					((Bool_factorContext)_localctx).nlabel =  ((Bool_factorContext)_localctx).ret.nlabel;

				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Rel_expressionContext extends ParserRuleContext {
		public int reg;
		public int label;
		public int btrue;
		public int bfalse;
		public int nlabel;
		public Arith_expressionContext ret;
		public Relation_opContext type;
		public Arith_expressionContext ret1;
		public List<Arith_expressionContext> arith_expression() {
			return getRuleContexts(Arith_expressionContext.class);
		}
		public Arith_expressionContext arith_expression(int i) {
			return getRuleContext(Arith_expressionContext.class,i);
		}
		public Relation_opContext relation_op() {
			return getRuleContext(Relation_opContext.class,0);
		}
		public Rel_expressionContext(ParserRuleContext parent, int invokingState) { super(parent, invokingState); }
		public Rel_expressionContext(ParserRuleContext parent, int invokingState, int reg, int label, int btrue, int bfalse) {
			super(parent, invokingState);
			this.reg = reg;
			this.label = label;
			this.btrue = btrue;
			this.bfalse = bfalse;
		}
		@Override public int getRuleIndex() { return RULE_rel_expression; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof CactusListener ) ((CactusListener)listener).enterRel_expression(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof CactusListener ) ((CactusListener)listener).exitRel_expression(this);
		}
	}

	public final Rel_expressionContext rel_expression(int reg,int label,int btrue,int bfalse) throws RecognitionException {
		Rel_expressionContext _localctx = new Rel_expressionContext(_ctx, getState(), reg, label, btrue, bfalse);
		enterRule(_localctx, 20, RULE_rel_expression);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(149);
			((Rel_expressionContext)_localctx).ret = arith_expression(_localctx.reg);
			setState(150);
			((Rel_expressionContext)_localctx).type = relation_op();
			setState(151);
			((Rel_expressionContext)_localctx).ret1 = arith_expression(((Rel_expressionContext)_localctx).ret.nreg);

				if(((Rel_expressionContext)_localctx).type.type == 1)
					System.out.print("\tbeq ");
				else if(((Rel_expressionContext)_localctx).type.type == 2)
					System.out.print("\tbne ");
				else if(((Rel_expressionContext)_localctx).type.type == 3)
					System.out.print("\tbgt ");
				else if(((Rel_expressionContext)_localctx).type.type == 4)
					System.out.print("\tbge ");
				else if(((Rel_expressionContext)_localctx).type.type == 5)
					System.out.print("\tblt ");
				else
					System.out.print("\tble ");

				System.out.println("$t" + ((Rel_expressionContext)_localctx).ret.place + ", $t" + ((Rel_expressionContext)_localctx).ret1.place + ", L" + (_localctx.label + 1));
				System.out.println("\tb L" + _localctx.label);

				System.out.println("L" + (_localctx.label + 1) + ":");
				System.out.println("\tb L" + _localctx.btrue);
				System.out.println("L" + _localctx.label + ":");

				((Rel_expressionContext)_localctx).nlabel =  _localctx.label + 2;

			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Relation_opContext extends ParserRuleContext {
		public int type;
		public TerminalNode ISEQUAL() { return getToken(CactusParser.ISEQUAL, 0); }
		public TerminalNode NOTEQUAL() { return getToken(CactusParser.NOTEQUAL, 0); }
		public TerminalNode GREATER() { return getToken(CactusParser.GREATER, 0); }
		public TerminalNode GREATEREQUAL() { return getToken(CactusParser.GREATEREQUAL, 0); }
		public TerminalNode LESS() { return getToken(CactusParser.LESS, 0); }
		public TerminalNode LESSEQUAL() { return getToken(CactusParser.LESSEQUAL, 0); }
		public Relation_opContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_relation_op; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof CactusListener ) ((CactusListener)listener).enterRelation_op(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof CactusListener ) ((CactusListener)listener).exitRelation_op(this);
		}
	}

	public final Relation_opContext relation_op() throws RecognitionException {
		Relation_opContext _localctx = new Relation_opContext(_ctx, getState());
		enterRule(_localctx, 22, RULE_relation_op);
		try {
			setState(166);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case ISEQUAL:
				enterOuterAlt(_localctx, 1);
				{
				setState(154);
				match(ISEQUAL);

					((Relation_opContext)_localctx).type =  1;

				}
				break;
			case NOTEQUAL:
				enterOuterAlt(_localctx, 2);
				{
				setState(156);
				match(NOTEQUAL);

					((Relation_opContext)_localctx).type =  2;

				}
				break;
			case GREATER:
				enterOuterAlt(_localctx, 3);
				{
				setState(158);
				match(GREATER);

					((Relation_opContext)_localctx).type =  3;

				}
				break;
			case GREATEREQUAL:
				enterOuterAlt(_localctx, 4);
				{
				setState(160);
				match(GREATEREQUAL);

					((Relation_opContext)_localctx).type =  4;

				}
				break;
			case LESS:
				enterOuterAlt(_localctx, 5);
				{
				setState(162);
				match(LESS);

					((Relation_opContext)_localctx).type =  5;

				}
				break;
			case LESSEQUAL:
				enterOuterAlt(_localctx, 6);
				{
				setState(164);
				match(LESSEQUAL);

					((Relation_opContext)_localctx).type =  6;

				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Arith_expressionContext extends ParserRuleContext {
		public int reg;
		public int nreg;
		public int place;
		public Arith_termContext ret;
		public Arith_expression1Context ret1;
		public Arith_termContext arith_term() {
			return getRuleContext(Arith_termContext.class,0);
		}
		public Arith_expression1Context arith_expression1() {
			return getRuleContext(Arith_expression1Context.class,0);
		}
		public Arith_expressionContext(ParserRuleContext parent, int invokingState) { super(parent, invokingState); }
		public Arith_expressionContext(ParserRuleContext parent, int invokingState, int reg) {
			super(parent, invokingState);
			this.reg = reg;
		}
		@Override public int getRuleIndex() { return RULE_arith_expression; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof CactusListener ) ((CactusListener)listener).enterArith_expression(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof CactusListener ) ((CactusListener)listener).exitArith_expression(this);
		}
	}

	public final Arith_expressionContext arith_expression(int reg) throws RecognitionException {
		Arith_expressionContext _localctx = new Arith_expressionContext(_ctx, getState(), reg);
		enterRule(_localctx, 24, RULE_arith_expression);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(168);
			((Arith_expressionContext)_localctx).ret = arith_term(_localctx.reg);
			setState(169);
			((Arith_expressionContext)_localctx).ret1 = arith_expression1(((Arith_expressionContext)_localctx).ret.nreg, ((Arith_expressionContext)_localctx).ret.place);

				((Arith_expressionContext)_localctx).nreg =  ((Arith_expressionContext)_localctx).ret1.nreg;
				((Arith_expressionContext)_localctx).place =  ((Arith_expressionContext)_localctx).ret1.nplace;

			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Arith_expression1Context extends ParserRuleContext {
		public int reg;
		public int place;
		public int nreg;
		public int nplace;
		public Arith_termContext ret;
		public Arith_expression1Context ret11;
		public Arith_expression1Context ret12;
		public TerminalNode ADD() { return getToken(CactusParser.ADD, 0); }
		public Arith_termContext arith_term() {
			return getRuleContext(Arith_termContext.class,0);
		}
		public Arith_expression1Context arith_expression1() {
			return getRuleContext(Arith_expression1Context.class,0);
		}
		public TerminalNode MINUS() { return getToken(CactusParser.MINUS, 0); }
		public Arith_expression1Context(ParserRuleContext parent, int invokingState) { super(parent, invokingState); }
		public Arith_expression1Context(ParserRuleContext parent, int invokingState, int reg, int place) {
			super(parent, invokingState);
			this.reg = reg;
			this.place = place;
		}
		@Override public int getRuleIndex() { return RULE_arith_expression1; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof CactusListener ) ((CactusListener)listener).enterArith_expression1(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof CactusListener ) ((CactusListener)listener).exitArith_expression1(this);
		}
	}

	public final Arith_expression1Context arith_expression1(int reg,int place) throws RecognitionException {
		Arith_expression1Context _localctx = new Arith_expression1Context(_ctx, getState(), reg, place);
		enterRule(_localctx, 26, RULE_arith_expression1);
		try {
			setState(185);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case ADD:
				enterOuterAlt(_localctx, 1);
				{
				setState(172);
				match(ADD);
				setState(173);
				((Arith_expression1Context)_localctx).ret = arith_term(_localctx.reg);

					System.out.println("\tadd $t" + _localctx.place + ", $t" + _localctx.place + ", $t" + ((Arith_expression1Context)_localctx).ret.place);

				setState(175);
				((Arith_expression1Context)_localctx).ret11 = arith_expression1(_localctx.reg, _localctx.place);

					((Arith_expression1Context)_localctx).nreg =  ((Arith_expression1Context)_localctx).ret11.nreg;
					((Arith_expression1Context)_localctx).nplace =  ((Arith_expression1Context)_localctx).ret11.nplace;

				}
				break;
			case MINUS:
				enterOuterAlt(_localctx, 2);
				{
				setState(178);
				match(MINUS);
				setState(179);
				((Arith_expression1Context)_localctx).ret = arith_term(_localctx.reg);

					System.out.println("\tsub $t" + _localctx.place + ", $t" + _localctx.place + ", $t" + ((Arith_expression1Context)_localctx).ret.place);

				setState(181);
				((Arith_expression1Context)_localctx).ret12 = arith_expression1(_localctx.reg, _localctx.place);

					((Arith_expression1Context)_localctx).nreg =  ((Arith_expression1Context)_localctx).ret12.nreg;
					((Arith_expression1Context)_localctx).nplace =  ((Arith_expression1Context)_localctx).ret12.nplace;

				}
				break;
			case SEMICOLON:
			case ISEQUAL:
			case NOTEQUAL:
			case GREATER:
			case GREATEREQUAL:
			case LESS:
			case LESSEQUAL:
			case LOGICALAND:
			case LOGICALOR:
			case RIGHTPARENTHESIS:
				enterOuterAlt(_localctx, 3);
				{

					((Arith_expression1Context)_localctx).nreg =  _localctx.reg;
					((Arith_expression1Context)_localctx).nplace =  _localctx.place;

				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Arith_termContext extends ParserRuleContext {
		public int reg;
		public int nreg;
		public int place;
		public Arith_factorContext ret;
		public Arith_term1Context ret1;
		public Arith_factorContext arith_factor() {
			return getRuleContext(Arith_factorContext.class,0);
		}
		public Arith_term1Context arith_term1() {
			return getRuleContext(Arith_term1Context.class,0);
		}
		public Arith_termContext(ParserRuleContext parent, int invokingState) { super(parent, invokingState); }
		public Arith_termContext(ParserRuleContext parent, int invokingState, int reg) {
			super(parent, invokingState);
			this.reg = reg;
		}
		@Override public int getRuleIndex() { return RULE_arith_term; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof CactusListener ) ((CactusListener)listener).enterArith_term(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof CactusListener ) ((CactusListener)listener).exitArith_term(this);
		}
	}

	public final Arith_termContext arith_term(int reg) throws RecognitionException {
		Arith_termContext _localctx = new Arith_termContext(_ctx, getState(), reg);
		enterRule(_localctx, 28, RULE_arith_term);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(187);
			((Arith_termContext)_localctx).ret = arith_factor(_localctx.reg);
			setState(188);
			((Arith_termContext)_localctx).ret1 = arith_term1(((Arith_termContext)_localctx).ret.nreg, ((Arith_termContext)_localctx).ret.place);

				((Arith_termContext)_localctx).nreg =  ((Arith_termContext)_localctx).ret1.nreg;
				((Arith_termContext)_localctx).place =  ((Arith_termContext)_localctx).ret1.nplace;

			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Arith_term1Context extends ParserRuleContext {
		public int reg;
		public int place;
		public int nreg;
		public int nplace;
		public Arith_factorContext ret;
		public Arith_term1Context ret13;
		public Arith_term1Context ret14;
		public Arith_term1Context ret15;
		public TerminalNode MULTIPLY() { return getToken(CactusParser.MULTIPLY, 0); }
		public Arith_factorContext arith_factor() {
			return getRuleContext(Arith_factorContext.class,0);
		}
		public Arith_term1Context arith_term1() {
			return getRuleContext(Arith_term1Context.class,0);
		}
		public TerminalNode DIVIDE() { return getToken(CactusParser.DIVIDE, 0); }
		public TerminalNode PERCENTAGE() { return getToken(CactusParser.PERCENTAGE, 0); }
		public Arith_term1Context(ParserRuleContext parent, int invokingState) { super(parent, invokingState); }
		public Arith_term1Context(ParserRuleContext parent, int invokingState, int reg, int place) {
			super(parent, invokingState);
			this.reg = reg;
			this.place = place;
		}
		@Override public int getRuleIndex() { return RULE_arith_term1; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof CactusListener ) ((CactusListener)listener).enterArith_term1(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof CactusListener ) ((CactusListener)listener).exitArith_term1(this);
		}
	}

	public final Arith_term1Context arith_term1(int reg,int place) throws RecognitionException {
		Arith_term1Context _localctx = new Arith_term1Context(_ctx, getState(), reg, place);
		enterRule(_localctx, 30, RULE_arith_term1);
		try {
			setState(210);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case MULTIPLY:
				enterOuterAlt(_localctx, 1);
				{
				setState(191);
				match(MULTIPLY);
				setState(192);
				((Arith_term1Context)_localctx).ret = arith_factor(_localctx.reg);

					System.out.println("\tmul $t" + _localctx.place + ", $t" + _localctx.place + ", $t" + ((Arith_term1Context)_localctx).ret.place);

				setState(194);
				((Arith_term1Context)_localctx).ret13 = arith_term1(_localctx.reg, _localctx.place);

					((Arith_term1Context)_localctx).nreg =  ((Arith_term1Context)_localctx).ret13.nreg;
					((Arith_term1Context)_localctx).nplace =  ((Arith_term1Context)_localctx).ret13.nplace;

				}
				break;
			case DIVIDE:
				enterOuterAlt(_localctx, 2);
				{
				setState(197);
				match(DIVIDE);
				setState(198);
				((Arith_term1Context)_localctx).ret = arith_factor(_localctx.reg);

					System.out.println("\tdiv $t" + _localctx.place + ", $t" + _localctx.place + ", $t" + ((Arith_term1Context)_localctx).ret.place);

				setState(200);
				((Arith_term1Context)_localctx).ret14 = arith_term1(_localctx.reg, _localctx.place);

					((Arith_term1Context)_localctx).nreg =  ((Arith_term1Context)_localctx).ret14.nreg;
					((Arith_term1Context)_localctx).nplace =  ((Arith_term1Context)_localctx).ret14.nplace;

				}
				break;
			case PERCENTAGE:
				enterOuterAlt(_localctx, 3);
				{
				setState(203);
				match(PERCENTAGE);
				setState(204);
				((Arith_term1Context)_localctx).ret = arith_factor(_localctx.reg);

					System.out.println("\trem $t" + _localctx.place + ", $t" + _localctx.place + ", $t" + ((Arith_term1Context)_localctx).ret.place);

				setState(206);
				((Arith_term1Context)_localctx).ret15 = arith_term1(_localctx.reg, _localctx.place);

					((Arith_term1Context)_localctx).nreg =  ((Arith_term1Context)_localctx).ret15.nreg;
					((Arith_term1Context)_localctx).nplace =  ((Arith_term1Context)_localctx).ret15.nplace;

				}
				break;
			case SEMICOLON:
			case ADD:
			case MINUS:
			case ISEQUAL:
			case NOTEQUAL:
			case GREATER:
			case GREATEREQUAL:
			case LESS:
			case LESSEQUAL:
			case LOGICALAND:
			case LOGICALOR:
			case RIGHTPARENTHESIS:
				enterOuterAlt(_localctx, 4);
				{

					((Arith_term1Context)_localctx).nreg =  _localctx.reg;
					((Arith_term1Context)_localctx).nplace =  _localctx.place;

				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Arith_factorContext extends ParserRuleContext {
		public int reg;
		public int nreg;
		public int place;
		public Arith_factorContext ret;
		public Primary_expressionContext ret1;
		public TerminalNode MINUS() { return getToken(CactusParser.MINUS, 0); }
		public Arith_factorContext arith_factor() {
			return getRuleContext(Arith_factorContext.class,0);
		}
		public Primary_expressionContext primary_expression() {
			return getRuleContext(Primary_expressionContext.class,0);
		}
		public Arith_factorContext(ParserRuleContext parent, int invokingState) { super(parent, invokingState); }
		public Arith_factorContext(ParserRuleContext parent, int invokingState, int reg) {
			super(parent, invokingState);
			this.reg = reg;
		}
		@Override public int getRuleIndex() { return RULE_arith_factor; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof CactusListener ) ((CactusListener)listener).enterArith_factor(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof CactusListener ) ((CactusListener)listener).exitArith_factor(this);
		}
	}

	public final Arith_factorContext arith_factor(int reg) throws RecognitionException {
		Arith_factorContext _localctx = new Arith_factorContext(_ctx, getState(), reg);
		enterRule(_localctx, 32, RULE_arith_factor);
		try {
			setState(219);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case MINUS:
				enterOuterAlt(_localctx, 1);
				{
				setState(212);
				match(MINUS);
				setState(213);
				((Arith_factorContext)_localctx).ret = arith_factor(_localctx.reg);

						System.out.println("\tneg $t" + ((Arith_factorContext)_localctx).ret.place + ", $t" + ((Arith_factorContext)_localctx).ret.place);
						((Arith_factorContext)_localctx).nreg =  ((Arith_factorContext)_localctx).ret.nreg;
						((Arith_factorContext)_localctx).place =  ((Arith_factorContext)_localctx).ret.place;
					
				}
				break;
			case CONST:
			case ID:
			case LEFTPARENTHESIS:
				enterOuterAlt(_localctx, 2);
				{
				setState(216);
				((Arith_factorContext)_localctx).ret1 = primary_expression(_localctx.reg);

						((Arith_factorContext)_localctx).nreg =  ((Arith_factorContext)_localctx).ret1.nreg;
						((Arith_factorContext)_localctx).place =  ((Arith_factorContext)_localctx).ret1.place;
					
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Primary_expressionContext extends ParserRuleContext {
		public int reg;
		public int nreg;
		public int place;
		public Token CONST;
		public Token ID;
		public Arith_expressionContext ret;
		public TerminalNode CONST() { return getToken(CactusParser.CONST, 0); }
		public TerminalNode ID() { return getToken(CactusParser.ID, 0); }
		public TerminalNode LEFTPARENTHESIS() { return getToken(CactusParser.LEFTPARENTHESIS, 0); }
		public TerminalNode RIGHTPARENTHESIS() { return getToken(CactusParser.RIGHTPARENTHESIS, 0); }
		public Arith_expressionContext arith_expression() {
			return getRuleContext(Arith_expressionContext.class,0);
		}
		public Primary_expressionContext(ParserRuleContext parent, int invokingState) { super(parent, invokingState); }
		public Primary_expressionContext(ParserRuleContext parent, int invokingState, int reg) {
			super(parent, invokingState);
			this.reg = reg;
		}
		@Override public int getRuleIndex() { return RULE_primary_expression; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof CactusListener ) ((CactusListener)listener).enterPrimary_expression(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof CactusListener ) ((CactusListener)listener).exitPrimary_expression(this);
		}
	}

	public final Primary_expressionContext primary_expression(int reg) throws RecognitionException {
		Primary_expressionContext _localctx = new Primary_expressionContext(_ctx, getState(), reg);
		enterRule(_localctx, 34, RULE_primary_expression);
		try {
			setState(230);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case CONST:
				enterOuterAlt(_localctx, 1);
				{
				setState(221);
				((Primary_expressionContext)_localctx).CONST = match(CONST);

						System.out.println("\tli $t" + _localctx.reg + ", " + (((Primary_expressionContext)_localctx).CONST!=null?((Primary_expressionContext)_localctx).CONST.getText():null));
						((Primary_expressionContext)_localctx).place =  _localctx.reg; // which register the const value is stored
						((Primary_expressionContext)_localctx).nreg =  _localctx.reg + 1; // increment the next available register number
					
				}
				break;
			case ID:
				enterOuterAlt(_localctx, 2);
				{
				setState(223);
				((Primary_expressionContext)_localctx).ID = match(ID);

						System.out.println("\tla $t" + _localctx.reg + ", " + (((Primary_expressionContext)_localctx).ID!=null?((Primary_expressionContext)_localctx).ID.getText():null));
						System.out.println("\tlw $t" + _localctx.reg + ", 0($t" + _localctx.reg + ")");
						((Primary_expressionContext)_localctx).place =  _localctx.reg; // which register the const value is stored
						((Primary_expressionContext)_localctx).nreg =  _localctx.reg + 1; // increment the next available register number
					
				}
				break;
			case LEFTPARENTHESIS:
				enterOuterAlt(_localctx, 3);
				{
				setState(225);
				match(LEFTPARENTHESIS);
				setState(226);
				((Primary_expressionContext)_localctx).ret = arith_expression(_localctx.reg);

						((Primary_expressionContext)_localctx).place =  ((Primary_expressionContext)_localctx).ret.place; // which register the const value is stored
						((Primary_expressionContext)_localctx).nreg =  ((Primary_expressionContext)_localctx).ret.nreg; // increment the next available register number
					
				setState(228);
				match(RIGHTPARENTHESIS);
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class TokenContext extends ParserRuleContext {
		public List<TerminalNode> ELSE() { return getTokens(CactusParser.ELSE); }
		public TerminalNode ELSE(int i) {
			return getToken(CactusParser.ELSE, i);
		}
		public List<TerminalNode> FI() { return getTokens(CactusParser.FI); }
		public TerminalNode FI(int i) {
			return getToken(CactusParser.FI, i);
		}
		public List<TerminalNode> IF() { return getTokens(CactusParser.IF); }
		public TerminalNode IF(int i) {
			return getToken(CactusParser.IF, i);
		}
		public List<TerminalNode> INT() { return getTokens(CactusParser.INT); }
		public TerminalNode INT(int i) {
			return getToken(CactusParser.INT, i);
		}
		public List<TerminalNode> MAIN() { return getTokens(CactusParser.MAIN); }
		public TerminalNode MAIN(int i) {
			return getToken(CactusParser.MAIN, i);
		}
		public List<TerminalNode> RETURN() { return getTokens(CactusParser.RETURN); }
		public TerminalNode RETURN(int i) {
			return getToken(CactusParser.RETURN, i);
		}
		public List<TerminalNode> WHILE() { return getTokens(CactusParser.WHILE); }
		public TerminalNode WHILE(int i) {
			return getToken(CactusParser.WHILE, i);
		}
		public List<TerminalNode> READ() { return getTokens(CactusParser.READ); }
		public TerminalNode READ(int i) {
			return getToken(CactusParser.READ, i);
		}
		public List<TerminalNode> WRITE() { return getTokens(CactusParser.WRITE); }
		public TerminalNode WRITE(int i) {
			return getToken(CactusParser.WRITE, i);
		}
		public List<TerminalNode> CONST() { return getTokens(CactusParser.CONST); }
		public TerminalNode CONST(int i) {
			return getToken(CactusParser.CONST, i);
		}
		public List<TerminalNode> COMMENT() { return getTokens(CactusParser.COMMENT); }
		public TerminalNode COMMENT(int i) {
			return getToken(CactusParser.COMMENT, i);
		}
		public List<TerminalNode> WHITESPACE() { return getTokens(CactusParser.WHITESPACE); }
		public TerminalNode WHITESPACE(int i) {
			return getToken(CactusParser.WHITESPACE, i);
		}
		public List<TerminalNode> SEMICOLON() { return getTokens(CactusParser.SEMICOLON); }
		public TerminalNode SEMICOLON(int i) {
			return getToken(CactusParser.SEMICOLON, i);
		}
		public List<TerminalNode> ID() { return getTokens(CactusParser.ID); }
		public TerminalNode ID(int i) {
			return getToken(CactusParser.ID, i);
		}
		public List<TerminalNode> ADD() { return getTokens(CactusParser.ADD); }
		public TerminalNode ADD(int i) {
			return getToken(CactusParser.ADD, i);
		}
		public List<TerminalNode> MINUS() { return getTokens(CactusParser.MINUS); }
		public TerminalNode MINUS(int i) {
			return getToken(CactusParser.MINUS, i);
		}
		public List<TerminalNode> MULTIPLY() { return getTokens(CactusParser.MULTIPLY); }
		public TerminalNode MULTIPLY(int i) {
			return getToken(CactusParser.MULTIPLY, i);
		}
		public List<TerminalNode> DIVIDE() { return getTokens(CactusParser.DIVIDE); }
		public TerminalNode DIVIDE(int i) {
			return getToken(CactusParser.DIVIDE, i);
		}
		public List<TerminalNode> PERCENTAGE() { return getTokens(CactusParser.PERCENTAGE); }
		public TerminalNode PERCENTAGE(int i) {
			return getToken(CactusParser.PERCENTAGE, i);
		}
		public List<TerminalNode> ISEQUAL() { return getTokens(CactusParser.ISEQUAL); }
		public TerminalNode ISEQUAL(int i) {
			return getToken(CactusParser.ISEQUAL, i);
		}
		public List<TerminalNode> NOTEQUAL() { return getTokens(CactusParser.NOTEQUAL); }
		public TerminalNode NOTEQUAL(int i) {
			return getToken(CactusParser.NOTEQUAL, i);
		}
		public List<TerminalNode> GREATER() { return getTokens(CactusParser.GREATER); }
		public TerminalNode GREATER(int i) {
			return getToken(CactusParser.GREATER, i);
		}
		public List<TerminalNode> GREATEREQUAL() { return getTokens(CactusParser.GREATEREQUAL); }
		public TerminalNode GREATEREQUAL(int i) {
			return getToken(CactusParser.GREATEREQUAL, i);
		}
		public List<TerminalNode> LESS() { return getTokens(CactusParser.LESS); }
		public TerminalNode LESS(int i) {
			return getToken(CactusParser.LESS, i);
		}
		public List<TerminalNode> LESSEQUAL() { return getTokens(CactusParser.LESSEQUAL); }
		public TerminalNode LESSEQUAL(int i) {
			return getToken(CactusParser.LESSEQUAL, i);
		}
		public List<TerminalNode> LOGICALAND() { return getTokens(CactusParser.LOGICALAND); }
		public TerminalNode LOGICALAND(int i) {
			return getToken(CactusParser.LOGICALAND, i);
		}
		public List<TerminalNode> LOGICALOR() { return getTokens(CactusParser.LOGICALOR); }
		public TerminalNode LOGICALOR(int i) {
			return getToken(CactusParser.LOGICALOR, i);
		}
		public List<TerminalNode> NOT() { return getTokens(CactusParser.NOT); }
		public TerminalNode NOT(int i) {
			return getToken(CactusParser.NOT, i);
		}
		public List<TerminalNode> ASSIGNMENT() { return getTokens(CactusParser.ASSIGNMENT); }
		public TerminalNode ASSIGNMENT(int i) {
			return getToken(CactusParser.ASSIGNMENT, i);
		}
		public List<TerminalNode> LEFTBRACE() { return getTokens(CactusParser.LEFTBRACE); }
		public TerminalNode LEFTBRACE(int i) {
			return getToken(CactusParser.LEFTBRACE, i);
		}
		public List<TerminalNode> RIGHTBRACE() { return getTokens(CactusParser.RIGHTBRACE); }
		public TerminalNode RIGHTBRACE(int i) {
			return getToken(CactusParser.RIGHTBRACE, i);
		}
		public List<TerminalNode> LEFTPARENTHESIS() { return getTokens(CactusParser.LEFTPARENTHESIS); }
		public TerminalNode LEFTPARENTHESIS(int i) {
			return getToken(CactusParser.LEFTPARENTHESIS, i);
		}
		public List<TerminalNode> RIGHTPARENTHESIS() { return getTokens(CactusParser.RIGHTPARENTHESIS); }
		public TerminalNode RIGHTPARENTHESIS(int i) {
			return getToken(CactusParser.RIGHTPARENTHESIS, i);
		}
		public TokenContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_token; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof CactusListener ) ((CactusListener)listener).enterToken(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof CactusListener ) ((CactusListener)listener).exitToken(this);
		}
	}

	public final TokenContext token() throws RecognitionException {
		TokenContext _localctx = new TokenContext(_ctx, getState());
		enterRule(_localctx, 36, RULE_token);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(235);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while ((((_la) & ~0x3f) == 0 && ((1L << _la) & ((1L << ELSE) | (1L << FI) | (1L << IF) | (1L << INT) | (1L << MAIN) | (1L << RETURN) | (1L << WHILE) | (1L << READ) | (1L << WRITE) | (1L << CONST) | (1L << SEMICOLON) | (1L << ID) | (1L << WHITESPACE) | (1L << COMMENT) | (1L << ADD) | (1L << MINUS) | (1L << MULTIPLY) | (1L << DIVIDE) | (1L << PERCENTAGE) | (1L << ISEQUAL) | (1L << NOTEQUAL) | (1L << GREATER) | (1L << GREATEREQUAL) | (1L << LESS) | (1L << LESSEQUAL) | (1L << LOGICALAND) | (1L << LOGICALOR) | (1L << NOT) | (1L << ASSIGNMENT) | (1L << LEFTBRACE) | (1L << RIGHTBRACE) | (1L << LEFTPARENTHESIS) | (1L << RIGHTPARENTHESIS))) != 0)) {
				{
				{
				setState(232);
				_la = _input.LA(1);
				if ( !((((_la) & ~0x3f) == 0 && ((1L << _la) & ((1L << ELSE) | (1L << FI) | (1L << IF) | (1L << INT) | (1L << MAIN) | (1L << RETURN) | (1L << WHILE) | (1L << READ) | (1L << WRITE) | (1L << CONST) | (1L << SEMICOLON) | (1L << ID) | (1L << WHITESPACE) | (1L << COMMENT) | (1L << ADD) | (1L << MINUS) | (1L << MULTIPLY) | (1L << DIVIDE) | (1L << PERCENTAGE) | (1L << ISEQUAL) | (1L << NOTEQUAL) | (1L << GREATER) | (1L << GREATEREQUAL) | (1L << LESS) | (1L << LESSEQUAL) | (1L << LOGICALAND) | (1L << LOGICALOR) | (1L << NOT) | (1L << ASSIGNMENT) | (1L << LEFTBRACE) | (1L << RIGHTBRACE) | (1L << LEFTPARENTHESIS) | (1L << RIGHTPARENTHESIS))) != 0)) ) {
				_errHandler.recoverInline(this);
				}
				else {
					if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
					_errHandler.reportMatch(this);
					consume();
				}
				}
				}
				setState(237);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static final String _serializedATN =
		"\3\u608b\ua72a\u8133\ub9ed\u417c\u3be7\u7786\u5964\3#\u00f1\4\2\t\2\4"+
		"\3\t\3\4\4\t\4\4\5\t\5\4\6\t\6\4\7\t\7\4\b\t\b\4\t\t\t\4\n\t\n\4\13\t"+
		"\13\4\f\t\f\4\r\t\r\4\16\t\16\4\17\t\17\4\20\t\20\4\21\t\21\4\22\t\22"+
		"\4\23\t\23\4\24\t\24\3\2\3\2\3\2\3\2\3\2\3\2\3\2\3\2\3\2\3\2\3\3\3\3\3"+
		"\3\3\3\3\3\3\3\5\39\n\3\3\4\3\4\3\4\3\4\3\4\5\4@\n\4\3\5\3\5\3\5\3\5\3"+
		"\5\3\5\3\5\3\5\3\5\3\5\3\5\3\5\3\5\3\5\3\5\3\5\3\5\3\5\3\5\3\5\3\5\3\5"+
		"\3\5\3\5\3\5\3\5\3\5\3\5\3\5\3\5\3\5\3\5\3\5\3\5\3\5\3\5\3\5\3\5\3\5\3"+
		"\5\3\5\3\5\5\5l\n\5\3\6\3\6\3\6\3\6\3\6\3\6\3\6\5\6u\n\6\3\7\3\7\3\7\3"+
		"\7\3\b\3\b\3\b\3\b\3\b\3\b\5\b\u0081\n\b\3\t\3\t\3\t\3\t\3\n\3\n\3\n\3"+
		"\n\3\n\3\n\5\n\u008d\n\n\3\13\3\13\3\13\3\13\3\13\3\13\3\13\5\13\u0096"+
		"\n\13\3\f\3\f\3\f\3\f\3\f\3\r\3\r\3\r\3\r\3\r\3\r\3\r\3\r\3\r\3\r\3\r"+
		"\3\r\5\r\u00a9\n\r\3\16\3\16\3\16\3\16\3\17\3\17\3\17\3\17\3\17\3\17\3"+
		"\17\3\17\3\17\3\17\3\17\3\17\3\17\5\17\u00bc\n\17\3\20\3\20\3\20\3\20"+
		"\3\21\3\21\3\21\3\21\3\21\3\21\3\21\3\21\3\21\3\21\3\21\3\21\3\21\3\21"+
		"\3\21\3\21\3\21\3\21\3\21\5\21\u00d5\n\21\3\22\3\22\3\22\3\22\3\22\3\22"+
		"\3\22\5\22\u00de\n\22\3\23\3\23\3\23\3\23\3\23\3\23\3\23\3\23\3\23\5\23"+
		"\u00e9\n\23\3\24\7\24\u00ec\n\24\f\24\16\24\u00ef\13\24\3\24\2\2\25\2"+
		"\4\6\b\n\f\16\20\22\24\26\30\32\34\36 \"$&\2\3\3\2\3#\2\u00f6\2(\3\2\2"+
		"\2\48\3\2\2\2\6?\3\2\2\2\bk\3\2\2\2\nt\3\2\2\2\fv\3\2\2\2\16\u0080\3\2"+
		"\2\2\20\u0082\3\2\2\2\22\u008c\3\2\2\2\24\u0095\3\2\2\2\26\u0097\3\2\2"+
		"\2\30\u00a8\3\2\2\2\32\u00aa\3\2\2\2\34\u00bb\3\2\2\2\36\u00bd\3\2\2\2"+
		" \u00d4\3\2\2\2\"\u00dd\3\2\2\2$\u00e8\3\2\2\2&\u00ed\3\2\2\2()\7\7\2"+
		"\2)*\7\"\2\2*+\7#\2\2+,\7 \2\2,-\b\2\1\2-.\5\4\3\2./\b\2\1\2/\60\5\6\4"+
		"\2\60\61\7!\2\2\61\3\3\2\2\2\62\63\7\6\2\2\63\64\7\16\2\2\64\65\7\r\2"+
		"\2\65\66\b\3\1\2\669\5\4\3\2\679\3\2\2\28\62\3\2\2\28\67\3\2\2\29\5\3"+
		"\2\2\2:;\5\b\5\2;<\5\6\4\2<=\b\4\1\2=@\3\2\2\2>@\b\4\1\2?:\3\2\2\2?>\3"+
		"\2\2\2@\7\3\2\2\2AB\7\16\2\2BC\7\37\2\2CD\5\32\16\2DE\b\5\1\2EF\7\r\2"+
		"\2Fl\3\2\2\2GH\7\n\2\2HI\7\16\2\2IJ\b\5\1\2Jl\7\r\2\2KL\7\13\2\2LM\5\32"+
		"\16\2MN\b\5\1\2NO\7\r\2\2Ol\3\2\2\2PQ\7\b\2\2QR\b\5\1\2Rl\7\r\2\2ST\b"+
		"\5\1\2TU\7\t\2\2UV\7\"\2\2VW\5\f\7\2WX\7#\2\2XY\7 \2\2YZ\b\5\1\2Z[\5\6"+
		"\4\2[\\\7!\2\2\\]\b\5\1\2]l\3\2\2\2^_\7\5\2\2_`\7\"\2\2`a\5\f\7\2ab\7"+
		"#\2\2bc\7 \2\2cd\b\5\1\2de\5\6\4\2ef\7!\2\2fg\b\5\1\2gh\5\n\6\2hi\7\4"+
		"\2\2ij\b\5\1\2jl\3\2\2\2kA\3\2\2\2kG\3\2\2\2kK\3\2\2\2kP\3\2\2\2kS\3\2"+
		"\2\2k^\3\2\2\2l\t\3\2\2\2mn\7\3\2\2no\7 \2\2op\5\6\4\2pq\7!\2\2qr\b\6"+
		"\1\2ru\3\2\2\2su\b\6\1\2tm\3\2\2\2ts\3\2\2\2u\13\3\2\2\2vw\5\20\t\2wx"+
		"\5\16\b\2xy\b\7\1\2y\r\3\2\2\2z{\7\35\2\2{|\5\20\t\2|}\5\16\b\2}~\b\b"+
		"\1\2~\u0081\3\2\2\2\177\u0081\b\b\1\2\u0080z\3\2\2\2\u0080\177\3\2\2\2"+
		"\u0081\17\3\2\2\2\u0082\u0083\5\24\13\2\u0083\u0084\5\22\n\2\u0084\u0085"+
		"\b\t\1\2\u0085\21\3\2\2\2\u0086\u0087\7\34\2\2\u0087\u0088\5\24\13\2\u0088"+
		"\u0089\5\22\n\2\u0089\u008a\b\n\1\2\u008a\u008d\3\2\2\2\u008b\u008d\b"+
		"\n\1\2\u008c\u0086\3\2\2\2\u008c\u008b\3\2\2\2\u008d\23\3\2\2\2\u008e"+
		"\u008f\7\36\2\2\u008f\u0090\5\24\13\2\u0090\u0091\b\13\1\2\u0091\u0096"+
		"\3\2\2\2\u0092\u0093\5\26\f\2\u0093\u0094\b\13\1\2\u0094\u0096\3\2\2\2"+
		"\u0095\u008e\3\2\2\2\u0095\u0092\3\2\2\2\u0096\25\3\2\2\2\u0097\u0098"+
		"\5\32\16\2\u0098\u0099\5\30\r\2\u0099\u009a\5\32\16\2\u009a\u009b\b\f"+
		"\1\2\u009b\27\3\2\2\2\u009c\u009d\7\26\2\2\u009d\u00a9\b\r\1\2\u009e\u009f"+
		"\7\27\2\2\u009f\u00a9\b\r\1\2\u00a0\u00a1\7\30\2\2\u00a1\u00a9\b\r\1\2"+
		"\u00a2\u00a3\7\31\2\2\u00a3\u00a9\b\r\1\2\u00a4\u00a5\7\32\2\2\u00a5\u00a9"+
		"\b\r\1\2\u00a6\u00a7\7\33\2\2\u00a7\u00a9\b\r\1\2\u00a8\u009c\3\2\2\2"+
		"\u00a8\u009e\3\2\2\2\u00a8\u00a0\3\2\2\2\u00a8\u00a2\3\2\2\2\u00a8\u00a4"+
		"\3\2\2\2\u00a8\u00a6\3\2\2\2\u00a9\31\3\2\2\2\u00aa\u00ab\5\36\20\2\u00ab"+
		"\u00ac\5\34\17\2\u00ac\u00ad\b\16\1\2\u00ad\33\3\2\2\2\u00ae\u00af\7\21"+
		"\2\2\u00af\u00b0\5\36\20\2\u00b0\u00b1\b\17\1\2\u00b1\u00b2\5\34\17\2"+
		"\u00b2\u00b3\b\17\1\2\u00b3\u00bc\3\2\2\2\u00b4\u00b5\7\22\2\2\u00b5\u00b6"+
		"\5\36\20\2\u00b6\u00b7\b\17\1\2\u00b7\u00b8\5\34\17\2\u00b8\u00b9\b\17"+
		"\1\2\u00b9\u00bc\3\2\2\2\u00ba\u00bc\b\17\1\2\u00bb\u00ae\3\2\2\2\u00bb"+
		"\u00b4\3\2\2\2\u00bb\u00ba\3\2\2\2\u00bc\35\3\2\2\2\u00bd\u00be\5\"\22"+
		"\2\u00be\u00bf\5 \21\2\u00bf\u00c0\b\20\1\2\u00c0\37\3\2\2\2\u00c1\u00c2"+
		"\7\23\2\2\u00c2\u00c3\5\"\22\2\u00c3\u00c4\b\21\1\2\u00c4\u00c5\5 \21"+
		"\2\u00c5\u00c6\b\21\1\2\u00c6\u00d5\3\2\2\2\u00c7\u00c8\7\24\2\2\u00c8"+
		"\u00c9\5\"\22\2\u00c9\u00ca\b\21\1\2\u00ca\u00cb\5 \21\2\u00cb\u00cc\b"+
		"\21\1\2\u00cc\u00d5\3\2\2\2\u00cd\u00ce\7\25\2\2\u00ce\u00cf\5\"\22\2"+
		"\u00cf\u00d0\b\21\1\2\u00d0\u00d1\5 \21\2\u00d1\u00d2\b\21\1\2\u00d2\u00d5"+
		"\3\2\2\2\u00d3\u00d5\b\21\1\2\u00d4\u00c1\3\2\2\2\u00d4\u00c7\3\2\2\2"+
		"\u00d4\u00cd\3\2\2\2\u00d4\u00d3\3\2\2\2\u00d5!\3\2\2\2\u00d6\u00d7\7"+
		"\22\2\2\u00d7\u00d8\5\"\22\2\u00d8\u00d9\b\22\1\2\u00d9\u00de\3\2\2\2"+
		"\u00da\u00db\5$\23\2\u00db\u00dc\b\22\1\2\u00dc\u00de\3\2\2\2\u00dd\u00d6"+
		"\3\2\2\2\u00dd\u00da\3\2\2\2\u00de#\3\2\2\2\u00df\u00e0\7\f\2\2\u00e0"+
		"\u00e9\b\23\1\2\u00e1\u00e2\7\16\2\2\u00e2\u00e9\b\23\1\2\u00e3\u00e4"+
		"\7\"\2\2\u00e4\u00e5\5\32\16\2\u00e5\u00e6\b\23\1\2\u00e6\u00e7\7#\2\2"+
		"\u00e7\u00e9\3\2\2\2\u00e8\u00df\3\2\2\2\u00e8\u00e1\3\2\2\2\u00e8\u00e3"+
		"\3\2\2\2\u00e9%\3\2\2\2\u00ea\u00ec\t\2\2\2\u00eb\u00ea\3\2\2\2\u00ec"+
		"\u00ef\3\2\2\2\u00ed\u00eb\3\2\2\2\u00ed\u00ee\3\2\2\2\u00ee\'\3\2\2\2"+
		"\u00ef\u00ed\3\2\2\2\178?kt\u0080\u008c\u0095\u00a8\u00bb\u00d4\u00dd"+
		"\u00e8\u00ed";
	public static final ATN _ATN =
		new ATNDeserializer().deserialize(_serializedATN.toCharArray());
	static {
		_decisionToDFA = new DFA[_ATN.getNumberOfDecisions()];
		for (int i = 0; i < _ATN.getNumberOfDecisions(); i++) {
			_decisionToDFA[i] = new DFA(_ATN.getDecisionState(i), i);
		}
	}
}